public class GenericPrint {
    // generic method printArray
   public <E> void printAnything( E inputAnything ) {
    // Display array elements
       System.out.println(inputAnything);
    
   }
 }


