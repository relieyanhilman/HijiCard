Hiji Card
Permainan kartu Tiruan seperti Uno Card 

Fitur:
House Rule
- Game ini dapat dimainkan oleh 2 hingga 6 orang pemain
- Setiap permainan dimulai (command F01 di-input), masing-masing pemain akan mendapatkan 7 buah kartu random dan akan ada satu kartu angka random untuk dijadikan sebagai kartu tengah
- Urutan giliran pemain akan diacak sekali di awal permainan
- Pada setiap giliran, pemain boleh mengeluarkan satu atau lebih kartu yang dapat dimainkan (terdeteksi valid) pada giliran tersebut
- Apabila pemain tidak mengeluarkan kartu, ia wajib mengambil satu kartu dari deck
- Apabila kartu yang baru diambil valid terhadap kartu tengah, pemain berhak memilih untuk mengeluarkan atau tidak mengeluarkan kartunya
- Apabila kartu tidak valid terhadap kartu tengah, giliran pemain tersebut selesai tanpa mengeluarkan kartu
- Kartu selain yang berjenis angka, memiliki powernya masing-masing
- Apabila pemain memiliki sisa satu kartu, maka pemain harus melakukan declare "HIJI" dalam waktu 3 detik. Apabila sudaa melebihi batas waktu, pemain wajib mengambil dua kartu dari deck
- Pemenang diambil dari pemain yang terlebih dahulu menghabiskan kartu yang sedang dipegang sudah habis dan permainan selesai



Deskripsi Power Card
- Skip          : Kartu yang apabila disubmit akan men-skip giliran pemain selanjutnya
- Reverse       : Kartu yang memiliki power untuk merubah urutan permainan menjadi berlawanan dari alur permainan sebelumnya
- Draw Two      : Kartu yang apabila di submit akan membuat pemain selanjutnya mengambil 2 kartu dari deck.
- Wild          : Kartu yang dapat submit untuk semua jenis warna dan pemain yang men-submit kartu ini diharuskan memilih warna yang akan digunakan untuk giliran selanjutnya
- Wild Four      : Sama seperti Wild hanya saja setelah kartu ini di submit, akan dibebankan tambahan 4 kartu dari deck kepada pemain selanjutnya yang tidak mempunyai kartu ini.


Tahapan Kompilasi dan Menjalankan Program
Memasukkan input command "Javac Main.java" kemudian "Java Main" pada terminal dan meng-nput fungsi yang ada sesuai keinginan (F01-F10 dan EXIT)


Bonus Implementasi
- Exception


Class
Class yang ada  menerapkan konsep :
- Inheritance
- Polymorphism
- Abstract Class/Interface
- Generic Class


Author :
Habiib Tsabit Az Zumar       18217010
Faras Banas Lubis            18217046
Muhammad Erwin Fattah        18219019
Relieyan  Ramadhan Hilman    18219089
Azka Alya Ramadhan           18219101